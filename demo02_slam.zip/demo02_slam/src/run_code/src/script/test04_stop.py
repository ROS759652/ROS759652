#! /usr/bin/env python3
# -*- coding: utf-8 -*

import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

class Obstacle():
    def __init__(self):
        self.count = 0
        self._cmd_pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)

        self.speed_go = Twist()
        self.speed_go.linear.x = 0.5

        self.speed_stop = Twist()
        self.speed_stop.linear.x = 0

        self.point1_left = 0.80
        self.point1_right = 0.84

        self.point2_left = 1.50
        self.point2_right = 1.52

        self.point3_left = 1.10
        self.point3_right = 1.13
        self.obstacle()

    def get_scan(self):
        msg = rospy.wait_for_message("scan", LaserScan)
        self.min = min(msg.ranges)
        

    def obstacle(self):
        self.twist = Twist()
        while not rospy.is_shutdown():
            self.get_scan()

            if self.count < 3:
                if  self.point1_left < self.min < self.point1_right:
                    for i in range(30):
                        self._cmd_pub.publish(self.speed_go)
                        rospy.loginfo(i)
                        rospy.loginfo(self.min)

                    self._cmd_pub.publish(self.speed_stop)
                    rospy.sleep(3)

                    for i in range(136):
                        self._cmd_pub.publish(self.speed_go)
                        rospy.loginfo(i)

                    self.count = self.count + 1
                    rospy.loginfo(self.count)

                else:
                    self.twist.linear.x = 0.5
                    self.twist.angular.z = 0.0
                    rospy.loginfo(self.min)

            if self.count == 3:
                if  self.point2_left < self.min < self.point2_right:
                    for i in range(80):
                        self._cmd_pub.publish(self.speed_go)
                        rospy.loginfo(i)
                        rospy.loginfo(self.min)

                    self._cmd_pub.publish(self.speed_stop)
                    rospy.sleep(5)

                    for i in range(150):
                        self._cmd_pub.publish(self.speed_go)
                        rospy.loginfo(i)

                    self.count = self.count + 1
                    rospy.loginfo(self.count)

                else:
                    self.twist.linear.x = 0.5
                    self.twist.angular.z = 0.0
                    rospy.loginfo(self.min)

            if self.count == 4:
                if  self.point3_left < self.min < self.point3_right:
                    for i in range(200):
                        self._cmd_pub.publish(self.speed_go)
                        rospy.loginfo(i)
                        rospy.loginfo(self.min)

                    self.count = self.count + 1
                    rospy.loginfo(self.count)

                else:
                    self.twist.linear.x = 0.5
                    self.twist.angular.z = 0.0
                    rospy.loginfo(self.min)
            
            if self.count == 5:
                if  self.point3_left < self.min < self.point3_right:
                    for i in range(200):
                        self._cmd_pub.publish(self.speed_go)
                        rospy.loginfo(i)
                        rospy.loginfo(self.min)

                    self.count = self.count + 1
                    rospy.loginfo(self.count)

                else:
                    self.twist.linear.x = 0.5
                    self.twist.angular.z = 0.0
                    rospy.loginfo(self.min)


            if self.count == 6:
                if  self.point3_left < self.min < self.point3_right:
                    for i in range(100):
                        self._cmd_pub.publish(self.speed_go)
                        rospy.loginfo(i)
                        rospy.loginfo(self.min)

                    self._cmd_pub.publish(self.speed_stop)
                    rospy.sleep(5)

                    for i in range(136):
                        self._cmd_pub.publish(self.speed_go)
                        rospy.loginfo(i)

                    self.count = self.count + 1
                    rospy.loginfo(self.count)

                else:
                    self.twist.linear.x = 0.5
                    self.twist.angular.z = 0.0
                    rospy.loginfo(self.min)


            self._cmd_pub.publish(self.twist)

def main():
    rospy.init_node('turtlebot_scan')
    try:
        obstacle = Obstacle()
    except rospy.ROSInterruptException:
        pass

if __name__ == '__main__':
    main()

# import rospy
# from sensor_msgs.msg import LaserScan
# from geometry_msgs.msg import Twist

# class Obstacle():

#     def __init__(self):
#         rospy.init_node('nav_pharmacy', anonymous=False)
#         #rospy.on_shutdown(self.shutdown)

#         self.point1_left = 0.80
#         self.point1_right = 0.83

#         self.count = 0 

#         self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist,queue_size=1000)
#         self.speed_go = Twist()
#         self.speed_go.linear.x = 0.5

#         self.speed_stop = Twist()
#         self.speed_stop.linear.x = 0

#         self.cam_sub=rospy.Subscriber('/scan', LaserScan, self.stop_callback,queue_size=10)

        
#     def stop_callback(self,data):
    
#     #msg = rospy.wait_for_message("scan", LaserScan)
    
#         rospy.loginfo(min(data.ranges))
    
#         self.cmd_vel_pub.publish(self.speed_go)
#         if self.point1_left < min(data.ranges) < self.point1_right:
#             count = count+1
#             rospy.loginfo(count)

#         if 0< self.count <= 2:
#             for i in range(120):
#                 self.cmd_vel_pub.publish(self.speed_go)
#                 rospy.loginfo(i)
#                 rospy.loginfo(min(data.ranges))
#             self.cmd_vel_pub.publish(self.speed_stop)
#             rospy.sleep(3)
#             for i in range(136):
#                 self.cmd_vel_pub.publish(self.speed_go)
#                 rospy.loginfo(i)
           
#         self.cmd_vel_pub.publish(self.speed_go)
#         rospy.loginfo(6)
#         #for i in range(360):
#                 #if  point1_left < data.ranges[i] < point1_right:
#                     #print(i)
#                     #count = 1

#     # if count == 1:
#     #    for j in range(3):
#     #     self.cmd_vel_pub.publish(speed_stop)
#     #     rospy.sleep(1)
#     #     print( "1", j)
#     #    count = 2

#     # if count == 2:
       
#     #     for j in range(3):
#     #         self.cmd_vel_pub.publish(speed_go)
#     #         rospy.sleep(1)
#     #         print(j)

#     # def shutdown(self):
#     #     rospy.loginfo("Stopping the robot...")
#     #     # Cancel any active goals
#     #     #self.move_base.cancel_goal()
#     #     #rospy.sleep(2)
#     #     # Stop the robot
#     #     self.cmd_vel_pub.publish(Twist())
#     #     rospy.sleep(1)


       

    
               
                
# def main():
#     rospy.init_node('turtlebot_scan')
#     try:
#         obstacle = Obstacle()
#     except rospy.ROSInterruptException:
#         pass

# if __name__ == '__main__':
#     main()