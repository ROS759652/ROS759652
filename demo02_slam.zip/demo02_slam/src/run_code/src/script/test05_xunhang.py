#!/usr/bin/env python3


import rospy
import actionlib
from actionlib_msgs.msg import *
from geometry_msgs.msg import Pose, Point, Quaternion, Twist
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from tf.transformations import quaternion_from_euler
from visualization_msgs.msg import Marker
from math import radians, pi

class MoveBaseSquare():
    def __init__(self):
        rospy.init_node('nav_test', anonymous=False)
        
        rospy.on_shutdown(self.shutdown)
        
        
        waypoints = list()
        
        # Append each of the four waypoints to the list.  Each waypoint
        # is a pose consisting of a position and orientation in the map frame.
        waypoints.append(Pose(Point(0.580, 0.028, 0.000),Quaternion(0.000, 0.000, 0.710, 0.704)))  # p #Position(0.549, 0.028, 0.000), Orientation(0.000, 0.000, 0.710, 0.704) = Angle: 1.579
        waypoints.append(Pose(Point(1.469, 1.512, 0.000),Quaternion(0.000, 0.000, -0.700, 0.714))) # 1 Position(1.469, 1.512, 0.000), Orientation(0.000, 0.000, -0.700, 0.714) = Angle: -1.551
        waypoints.append(Pose(Point(1.503, -0.391, 0.000), Quaternion(0.000, 0.000, 1.000, 0.005))) # 2 Position(1.503, -0.391, 0.000), Orientation(0.000, 0.000, 1.000, 0.005) = Angle: 3.132
        waypoints.append(Pose(Point(0.031, 0.070, 0.000), Quaternion(0.000, 0.000, -1.000, 0.015))) # 7 Position(0.031, 0.070, 0.000), Orientation(0.000, 0.000, -1.000, 0.015) = Angle: -3.111
        waypoints.append(Pose(Point(-1.904, 0.148, 0.000), Quaternion(0.000, 0.000, 0.759, 0.651))) # 0 Position(-1.904, 0.148, 0.000), Orientation(0.000, 0.000, 0.759, 0.651) = Angle: 1.723
        waypoints.append(Pose(Point(-0.941, 1.423, 0.000), Quaternion(0.000, 0.000, 1.000, 0.016))) # 3 Position(-0.941, 1.423, 0.000), Orientation(0.000, 0.000, 1.000, 0.016) = Angle: 3.110
        waypoints.append(Pose(Point(-2.192, 1.190, 0.000), Quaternion(0.000, 0.000, -0.697, 0.717))) # 4 Position(-2.192, 1.190, 0.000), Orientation(0.000, 0.000, -0.697, 0.717) = Angle: -1.543
        waypoints.append(Pose(Point(-2.107, -1.754, 0.000), Quaternion(0.000, 0.000, 0.027, 1.000))) # 5 Position(-2.107, -1.754, 0.000), Orientation(0.000, 0.000, 0.027, 1.000) = Angle: 0.055
        waypoints.append(Pose(Point(-0.813, -1.695, 0.000), Quaternion(0.000, 0.000, 0.878, 0.478))) # 6 Position(-0.813, -1.695, 0.000), Orientation(0.000, 0.000, 0.878, 0.478) = Angle: 2.145
        waypoints.append(Pose(Point(-1.754, -0.087, 0.000), Quaternion(0.000, 0.000, 0.033, 0.999))) # -0 Position(-1.754, -0.087, 0.000), Orientation(0.000, 0.000, 0.033, 0.999) = Angle: 0.065
        


        
        
        self.cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=5)
        
        # Subscribe to the move_base action server
        self.move_base = actionlib.SimpleActionClient("move_base", MoveBaseAction)
        
        rospy.loginfo("Waiting for move_base action server...")
        
        # Wait 60 seconds for the action server to become available
        self.move_base.wait_for_server(rospy.Duration(60))
        
        rospy.loginfo("Connected to move base server")
        rospy.loginfo("Starting navigation test")
        
        # Initialize a counter to track waypoints
        i = 0
        
        # Cycle through the four waypoints
        while i < 10 and not rospy.is_shutdown():
            # Update the marker display
           
            
            # Intialize the waypoint goal
            goal = MoveBaseGoal()
            
            # Use the map frame to define goal poses
            goal.target_pose.header.frame_id = 'map'
            
            # Set the time stamp to "now"
            goal.target_pose.header.stamp = rospy.Time.now()
            
            # Set the goal pose to the i-th waypoint
            goal.target_pose.pose = waypoints[i]
            
            # Start the robot moving toward the goal
            self.move(goal)
            
            i += 1

        if i == 10 and not rospy.is_shutdown():
            goal = MoveBaseGoal()
            
            # Use the map frame to define goal poses
            goal.target_pose.header.frame_id = 'map'
            
            # Set the time stamp to "now"
            goal.target_pose.header.stamp = rospy.Time.now()
            
            # Set the goal pose to the i-th waypoint
            goal.target_pose.pose = waypoints[3]
            
            # Start the robot moving toward the goal
            self.move(goal)
            
            i += 1


    def move(self, goal):
            # Send the goal pose to the MoveBaseAction server
            self.move_base.send_goal(goal)
            
            # Allow 1 minute to get there
            finished_within_time = self.move_base.wait_for_result(rospy.Duration(60)) 
            
            # If we don't get there in time, abort the goal
            if not finished_within_time:
                self.move_base.cancel_goal()
                rospy.loginfo("Timed out achieving goal")
            else:
                # We made it!
                state = self.move_base.get_state()
                if state == GoalStatus.SUCCEEDED:
                    rospy.loginfo("Goal succeeded!")
                    
    

    def shutdown(self):
        rospy.loginfo("Stopping the robot...")
        
        self.cmd_vel_pub.publish(Twist())
        rospy.sleep(1)
        rospy.loginfo("Navigation test finished.")

if __name__ == '__main__':
    try:
        MoveBaseSquare()
    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation test finished.")