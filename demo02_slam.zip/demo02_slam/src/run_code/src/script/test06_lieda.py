#! /usr/bin/env python3
# -*- coding: utf-8 -*
import rospy
from sensor_msgs.msg import LaserScan

def leida_callback(data):
  rospy.loginfo(min(data.ranges))
  #rospy.loginfo(data.range_)

if __name__ == '__main__': 
  try:
    rospy.init_node("leida")
    scan_sub = rospy.Subscriber('/scan', LaserScan, leida_callback)
    rospy.spin()
    
  except rospy.ROSInterruptException:
    pass